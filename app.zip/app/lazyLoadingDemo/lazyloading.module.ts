import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LazyLoadedComponent } from './lazyloading.component';




console.warn("lazy loaded module called..")
@NgModule({
 declarations :[LazyLoadedComponent]
})
export class LazyLoadedModuleDemo { }
