import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DemoApiComponent } from './demoComponent/demo.component';
import { DemoLiveComponent } from './demoComponent/livedemo.component';

import { ReactiveFormComponentExample } from './formComponent/reactiveForm.component';


import { AuthGuard } from './routeguardcanactivate.service';
import { MyComponent } from './second.component';


const routes: Routes = [
  
  {path : 'demo', component: DemoApiComponent},
  {path: 'second',component:MyComponent,  canActivate:[AuthGuard]},
  {path: 'lazyloading', loadChildren:() => import('./lazyLoadingDemo/lazyloading.module')},
  {path:'testform',component: ReactiveFormComponentExample},
  {path:'demolive',component:DemoLiveComponent}
  
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  
})
export class AppRoutingModule { }
