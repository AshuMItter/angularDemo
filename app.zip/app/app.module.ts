import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatSliderModule } from '@angular/material/slider';
import {MatButtonModule} from '@angular/material/button';




import {MatProgressBarModule} from '@angular/material/progress-bar';

import {MatMenuModule} from '@angular/material/menu';
import {MatRippleModule} from '@angular/material/core';

import {MatSelectModule} from '@angular/material/select';

import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatTableModule} from '@angular/material/table';

import {MatToolbarModule} from '@angular/material/toolbar';

import {MatIconModule} from '@angular/material/icon';

import {MatDialogModule} from '@angular/material/dialog';

import {MatFormFieldModule} from '@angular/material/form-field';

import {MatButtonToggleModule} from '@angular/material/button-toggle';

import {MatGridListModule} from '@angular/material/grid-list';

import {MatInputModule} from '@angular/material/input';

import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';

import {MatDatepickerModule} from '@angular/material/datepicker';

import {MatTabsModule} from '@angular/material/tabs';


import {MatBadgeModule} from '@angular/material/badge';

import {MatExpansionModule} from '@angular/material/expansion';


import {MatTooltipModule} from '@angular/material/tooltip';

import { DemoApiComponent } from './demoComponent/demo.component';

import { HttpClientModule } from '@angular/common/http';
import { MyComponent } from './second.component';
import { AuthGuard } from './routeguardcanactivate.service';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormComponentExample } from './formComponent/reactiveForm.component';
import { LazyLoadedComponent } from './lazyLoadingDemo/lazyloading.component';
import { DemoLiveComponent } from './demoComponent/livedemo.component';


@NgModule({
  declarations: [
    AppComponent,
    ReactiveFormComponentExample,
    DemoLiveComponent
    
    
    
   
    
  ],
  imports: [
    BrowserModule,   
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatButtonModule,
    MatProgressBarModule,
    MatMenuModule,
    MatRippleModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTableModule,
    MatToolbarModule,
    MatIconModule,
    MatDialogModule,
MatDatepickerModule,
MatFormFieldModule,
MatButtonToggleModule,
MatGridListModule,
MatProgressSpinnerModule,
MatInputModule,
MatBadgeModule,
MatTabsModule,
MatTooltipModule,
MatAutocompleteModule,
MatExpansionModule


  ],
  providers: [HttpClientModule,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
