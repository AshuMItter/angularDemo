import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validator, Validators } from '@angular/forms';


@Component({
    selector: 'form-temp',
    templateUrl: './reactiveForm.component.html'
     
  })
  
export class ReactiveFormComponentExample implements OnInit  {
    
  
  constructor(){
    console.log("ReactiveFormComponent has loaded...");
  }
  profileForm = new FormGroup({
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('',[Validators.required,Validators.email]),

  
  });
  
  
  ngOnInit() { 
  
 } 
 onSubmit() {
   if(this.profileForm.valid){
  console.warn(this.profileForm.controls['lastName'].value);
  console.warn(this.profileForm.controls['firstName'].value);
  // TODO: Use EventEmitter with form value
  console.warn(this.profileForm.value);
}
}
 

    
}