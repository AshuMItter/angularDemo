import { Component } from "@angular/core";
import { combineLatestInit } from "rxjs/internal/observable/combineLatest";

@Component({
    selector: 'tageName',
    template: '<h1> Hello from Demo Live Component</h1>'
})
export class DemoLiveComponent{

    constructor(){

        console.warn("Demo Live component got loaded...");
    }
}