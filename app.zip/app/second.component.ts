import { Component } from '@angular/core';

@Component({
  selector: 'three',
  template: '<h1>My Component<h1>'
 
})
export class MyComponent {
constructor(){
  console.log("MyComponent Loaded");
}

}


