import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

import { catchError, Observable, observable, throwError } from 'rxjs';

// can be automatically converted to it unline class
export interface Employees {
  id: number;
  first_name: string;
  last_name: any;
  email: string;
}

@Component({
    selector: 'one',
    template: '<h1>Hi <u> {{firstName}} ! </u> Your id id <u>{{id}} </u> while email id <u> {{email_id}}</u></h1>',
   
  })
  export class DemoApiComponent{

    email_id: any;
    id: any;
    firstName: any;
   
      constructor(private httpClient : HttpClient){
   console.log("Api component")

    



    
      console.log('DemoApiComponent loaded..')
      httpClient.get<Employees[]>("http://localhost:3000/employees").subscribe(data=>{
        
        this.email_id = data[0].email;
        this.id = data[0].id;
        this.firstName = data[0].first_name;
       
      
    
      });
    
    
    
    
       
     let employe : Employees = {
       id: 70,
       first_name: "Ashu",
       last_name: "Meet",
       email: "ashu@gmail.com"
     }
     

        
      httpClient.post<Employees>("http://localhost:3000/employees",employe).subscribe( data => console.log(data),er => alert());
     
  }

}
